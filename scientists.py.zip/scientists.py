# Imports
import tensorflow as tf 
from tensorflow import keras 
import os 
import numpy as np 
from matplotlib import pyplot as plt 
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.preprocessing import image 

# Rescale the training images 
train_img = ImageDataGenerator(rescale=1/255.0)

# Making the training dataset 
train_dataset = train_img.flow_from_directory('/Users/yashsolanki/Desktop/Neural Networks/Scientists', 
                                            target_size=(200, 200), 
                                            batch_size=1, 
                                            class_mode='binary')

# Getting the class indices
print(train_dataset.class_indices)
# {'Erwin Shoordinger': 0, 'Stephen Hawking': 1}

# Making the model 
model = keras.Sequential([
    keras.layers.Conv2D(64, 3, activation='relu'), 
    keras.layers.Conv2D(32, 3, activation='relu'), 
    keras.layers.Flatten(), 
    keras.layers.Dense(2, activation='softmax')
])

# Compiling the model
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# Fitting the model 
model.fit(train_dataset, epochs=9, batch_size=1)

# Saving the model 
model.save("scientist_model.h5")

dir_path = "/Users/yashsolanki/Desktop/Neural Networks/scientists testing data"

for i in os.listdir(dir_path ):
    # Using matplotlib to show the images
    img = image.load_img(dir_path+'//'+i, target_size=(200, 200))
    plt.imshow(img)
    plt.show()

    X = image.img_to_array(img)
    X = np.expand_dims(X, axis=0)
    images = np.vstack([X])

    val = model.predict(images)
    print(val)
    if round(val[0][0]) == 0:
        plt.title("Erwin Schoordinger")
        print("Erwin Schoordinger")

    if round(val[0][0]) == 1:
        plt.title("Stephen Hawking")
        print("Stephen Hawking")